//var socket = io.connect('http://localhost:8080', { 'forceNew': true });
var socket = io.connect( location.host, { 'forceNew': true });

if (localStorage.lpID) {	 //Local player ID
	//lpID = localStorage.getItem("lpID")
}else{
	lpID = Math.floor(Math.random() * 10000);
	localStorage.lpID = lpID.toString(16);
}

function ping(){
	socket.emit('pinga', localStorage.lpID);
	console.log(localStorage.lpID);
	setTimeout(function(){ ping(); }, 30000);//TIENE QUE SER 30 SEG
}	

function loadCfg(){
	socket.emit('retcfg', localStorage.lpID);
	socket.on('cfg', function(data) {
		set(data);
	});
}

var cfg = new Object();
function set(data){
	cfg = data;
	console.log (cfg);
	setConfig()
}

function send (msj){
	socket.emit('bttn', msj);
}