	var pyr = 1;
	var cfg = 1;
		//PADS ACTUALIZACION
	var TC = document.getElementById("TC").getBoundingClientRect(); 
	var CA4B = document.getElementById("CA4B").getBoundingClientRect(); 
	var CA6B = document.getElementById("CA6B").getBoundingClientRect(); 
	var CA8P = document.getElementById("CA8P").getBoundingClientRect(); 
	var CP1 = document.getElementById("CP1").getBoundingClientRect(); 
	var CP2 = document.getElementById("CP2").getBoundingClientRect(); 
	
	function actualizarTPs(){
		TC = document.getElementById("TC").getBoundingClientRect();
		CA4B = document.getElementById("CA4B").getBoundingClientRect(); 
		CA6B = document.getElementById("CA6B").getBoundingClientRect(); 
		CA8P = document.getElementById("CA8P").getBoundingClientRect(); 
		CP1 = document.getElementById("CP1").getBoundingClientRect(); 
		CP2 = document.getElementById("CP2").getBoundingClientRect(); 
	}
	
	
	/* AUXILIAR PARA KEYBOARD*/
		var sAux = 0;
		var yAux = 0;
		function shift(){
			var El = document.getElementsByClassName('key');
			(sAux ==  0)? sAux = 1: sAux =  0;
			yAux = 0;
			for(i=0; i < El.length; i++){
				if (El[i].value){
					El[i].innerHTML = El[i].value[sAux];
				}
			}
		}
		
		function sym(){
			var El = document.getElementsByClassName('key');
			(yAux ==  0)? yAux = 2: yAux =  0;
			sAux = 0;
			for(i=0; i < El.length; i++){
				if (El[i].value){
					El[i].innerHTML = El[i].value[yAux];
				}
			}
		}
	
	
	
	function sendm(id){ //send Media
		event.preventDefault();
		send(">>"+pyr+"n"+id);
	}

	function sendk(El){
		event.preventDefault();
		//var El = document.getElementById(id);
		var key;
		if (El.value) {
			key = El.value[sAux + yAux].charCodeAt(0);
		}else{	
			switch (El.id) {
				case "BACKSPACE":
					 key = 08;
					break;
				case "ENTER":
					key = "ENTER";
					break;
				case "SPACE":
					key = 32;
					break;
				case "S.":
					key = ".".charCodeAt(0);
					break;
				default:
					key.charCodeAt(0)
			}
		}
		send(">>"+pyr+"k"+key);
	}

	function sjkd(id){//send joystick button down
		event.preventDefault();
		send(">>"+pyr+"jD"+id);
	}

	function sjku(id){//send joystick button up
		event.preventDefault();
		send(">>"+pyr+"jU"+id);
	}
	
	
	var lASnd = "NA"; //last arrow send
	function sendCA(CA) { //send joystick arrow poss
		if (lASnd != CA){
			send(">>"+pyr+"jU"+lASnd);
			lASnd = CA;
			send(">>"+pyr+"jD"+lASnd);
		}
	}
	
	
	
/*
	var lASnd = "NA"; //last arrow send
	function sendCA(event,CA) { //send joystick arrow poss
		event.preventDefault();
		var x = event.touches[0].clientX - CA.left;
		var y = event.touches[0].clientY - CA.top;
			if ((x >= 0) && (x <= CA.width) &&  (y >= 0) && (y <= CA.height)){
			
			var xp = Math.floor(x / CA.width*3);
			var yp = Math.floor(y / CA.height*3)*3;
			var arrArr = ["UpLe","Up","UpRi","Le","","Ri","DwLe","Dw","DwRi"]  

			xp = xp > 2 ? 2 : xp < 0 ? 0 : xp
			yp = yp > 6 ? 6 : yp < 0 ? 0 : yp
			if (lASnd != arrArr[xp+yp]){
				send(">>"+pyr+"jU"+lASnd);
				lASnd = arrArr[xp+yp];
				send(">>"+pyr+"jD"+lASnd);
			}
		}
	}

	function sendCAu(){//send joystick arrow poss up
		event.preventDefault();
		send(">>"+pyr+"jU"+lASnd);
		lASnd = "NA";
	}*/
	
	var lPSnd = new Array(); //last pov send
	function sendCP(n,ang){ //send joystick pov		
		lPSnd[n]? "":361;
		if (lPSnd[n] != ang){
			send(">>"+pyr+"jP"+n+""+ang);
			lPSnd[n] = ang;
		}	
	}
	
/*
	function sendCP(n,event) { //send joystick pov
		event.preventDefault();
		var CP = n == 1? CP1: CP2; 
		var x = event.touches[0].clientX - (CP.left + CP.width/2);
		var y = event.touches[0].clientY - (CP.top + CP.height/2);
		if ((x <= CP.width/2) && (y <= CP.height/2)){

			var ang = Math.floor(180 - Math.atan2(x ,  y)* 180 / Math.PI);
			//var xp = Math.floor(x / CA.width*3);
			//var yp = Math.floor(y / CA.height*3)*3;
			//document.getElementById("CP1").innerHTML = Math.floor(180 - Math.atan2(x ,  y)* 180 / Math.PI);
			console.log(pyr+"jP"+n+""+ang)
			send(">>"+pyr+"jP"+n+""+ang);
		}
	}



	function sendCPu(n){//send joystick arrow poss up
		event.preventDefault();
		send(">>"+pyr+"jP"+n+""+"361");
	}
*/
	function sendTC(event) { //send mouse Touchpad
		var x = event.touches[0].clientX - TC.left ;
		var y = event.touches[0].clientY - TC.top;
		var xp = Math.floor(x / TC.width*10000 + 0.5);
		var yp = Math.floor(y / TC.height*10000);
		event.preventDefault();
		send(">>"+pyr+"mT"+xp+"/"+yp);
		document.getElementById("TC").innerHTML = xp + ", " + yp;
	}

	function sjcd(id){ //send , mouse button down
		event.preventDefault();
		send(">>"+pyr+"mD"+id);
	}

	function sjcu(id){ //send mouse button up
		event.preventDefault();
		send(">>"+pyr+"mU"+id);
	}